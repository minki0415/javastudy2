package dev.pomyharry.stocksimulator.back.controller;

public @interface Autowried {

}
